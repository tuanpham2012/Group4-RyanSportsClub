let blankFullname = 'Full Name không được để trống';
let blankEmail = 'Email không được để trống';
let blankPhone = 'Mobile Phone không được để trống';
let blankCountry = 'Vui lòng nhập quốc gia của bạn';
let blankGender = 'Vui lòng chọn giới tính';

let errorFullname = 'Full Name in không hợp lệ';
let errorEmail = 'Email không hợp lệ';
let errorPhone = 'Vui lòng nhập đủ 10 số';
let errorCountry = 'Vui lòng nhập quốc gia của bạn';
let errorGender = 'Vui lòng chọn giới tính';

let fullNameRegex = /^[a-zA-Z\s]+$/;
let emailRegex = /^\S+@\S+\.\S+$/;
let phoneRegex = /^\d{10}$/;

function printError(elementid, hintMess) {
    // elementid: là thẻ html mà có lỗi
    // hintMess: là thông báo lỗi
    document.getElementById(elementid).innerHTML = hintMess;
}

function validateForm(e) {
    e.preventDefault();
    var formData = Object.fromEntries(new FormData(document.querySelector('form')).entries());

    // kiểm tra fullname
    if (!formData.name) {
        printError("NameErr", blankFullname);
    } else {
        !fullNameRegex.test(formData.name) ? printError("NameErr", errorFullname) : printError("NameErr", "");
    }

    // kiểm tra email
    if (!formData.email) {
        !printError("EmailErr", blankEmail);
    } else {
        !emailRegex.test(formData.email) ? printError("EmailErr", errorEmail) : printError("EmailErr", "");

    }

    // kiểm tra số phone - bắt buộc 10 số
    if (!formData.phone) {
        printError("PhoneErr", blankPhone);
    } else {
        !phoneRegex.test(formData.phone) ? printError("PhoneErr", errorPhone) : printError("PhoneErr", "");
    }

    // kiểm tra quốc gia
    !formData.country ? printError("CountryErr", blankGender) : printError("CountryErr", "");

    // kiểm tra gender
    !formData.gender ? printError("GenderErr", blankGender) : printError("GenderErr", "");

    // Ngăn chạn user ấn nút Submit khi có bất cứ field nào có lỗi!
    if (!formData.name || !formData.email || !formData.phone || !formData.country || !formData.gender) {
        document.getElementsByClassName('modal-title')[0].innerText = "Error";
        document.getElementsByClassName('modal-body')[0].innerText = "Vui long nhap day du thong tin";
    } else {
        document.getElementsByClassName('modal-title')[0].innerText = "Form Data";
        document.getElementsByClassName('modal-body')[0].innerText =
            "Bạn đã nhập dữ liệu chi tiết sau:\n" +
            "- Full Name: " +
            formData.name +
            "\n" +
            "- Email: " +
            formData.email +
            "\n" +
            "- Mobile: " +
            formData.phone +
            "\n" +
            "- Country: " +
            formData.country +
            "\n" +
            "- Gender: " +
            formData.gender +
            "\n";
    }

}

function resetForm() {
    var errorClass = document.getElementsByClassName("error");
    for (var i = 0; i < errorClass.length; i++) {
        errorClass[i].innerHTML = "";

    }
}